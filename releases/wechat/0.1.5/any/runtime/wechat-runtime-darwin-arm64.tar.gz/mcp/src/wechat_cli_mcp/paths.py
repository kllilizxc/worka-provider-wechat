from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _user_data_root() -> Path:
    configured = os.environ.get("WECHAT_MCP_RUNTIME_DIR", "").strip()
    if configured:
        return Path(configured).expanduser()
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "wechat-local-agent-mcp"
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return base / "wechat-local-agent-mcp"
    base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "wechat-local-agent-mcp"


RUNTIME_ROOT = _user_data_root() / "v1"


def _first_file(candidates: list[Path]) -> Path | None:
    for candidate in candidates:
        try:
            if candidate.expanduser().is_file():
                return candidate.expanduser().resolve()
        except OSError:
            continue
    return None


def _runtime_matches(name: str) -> list[Path]:
    root = PROJECT_ROOT / ".runtime" / "upstream"
    if not root.is_dir():
        return []
    return list(root.glob(f"**/{name}"))


def discover_cli() -> str:
    configured = os.environ.get("WECHAT_MCP_CLI_PATH", "").strip()
    if configured:
        return str(Path(configured).expanduser())
    executable = "wechat-cli.exe" if os.name == "nt" else "wechat-cli"
    on_path = shutil.which(executable) or shutil.which("wechat-cli")
    candidates = [
        Path(on_path) if on_path else Path("__missing__"),
        RUNTIME_ROOT.parent / "upstream" / executable,
        PROJECT_ROOT / ".runtime" / "bin" / executable,
        *_runtime_matches(executable),
    ]
    found = _first_file(candidates)
    return str(found) if found else executable


def discover_wcdb(cli_path: str) -> str:
    configured = (
        os.environ.get("WECHAT_MCP_WCDB_LIB", "").strip()
        or os.environ.get("WECHAT_CLI_WCDB_LIB", "").strip()
        or os.environ.get("WECHAT_CLI_WCDB_DYLIB", "").strip()
    )
    if configured:
        return str(Path(configured).expanduser())
    library_names = ["libWCDB.dll", "WCDB.dll"] if os.name == "nt" else ["libWCDB.dylib"]
    cli_parent = Path(cli_path).expanduser().parent
    candidates: list[Path] = []
    for name in library_names:
        candidates.extend(
            [
                cli_parent / name,
                PROJECT_ROOT / ".runtime" / "lib" / name,
                *_runtime_matches(name),
            ]
        )
    found = _first_file(candidates)
    return str(found) if found else ""


def discover_ocr() -> Path:
    configured = os.environ.get("WECHAT_MCP_OCR_BINARY", "").strip()
    executable = "wechat-image-ocr.exe" if os.name == "nt" else "wechat-image-ocr"
    candidates = [
        Path(configured).expanduser() if configured else Path("__missing__"),
        PROJECT_ROOT / ".runtime" / "bin" / executable,
        PROJECT_ROOT / "bin" / executable,
    ]
    return _first_file(candidates) or candidates[1]


def discover_asr_python() -> str:
    configured = os.environ.get("WECHAT_MCP_ASR_PYTHON", "").strip()
    if configured:
        return str(Path(configured).expanduser())
    candidates = [
        Path.home() / ".wechat-cli" / "asr-venv" / "bin" / "python3",
        Path.home() / ".wechat-cli" / "asr-venv" / "Scripts" / "python.exe",
    ]
    found = _first_file(candidates)
    return str(found) if found else ""
