from __future__ import annotations

import html
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable
from urllib.error import HTTPError
from urllib.parse import urljoin, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener
from xml.etree import ElementTree

from .paths import RUNTIME_ROOT, discover_ocr


MAX_ENRICHMENT_BYTES = 4 * 1024 * 1024
MAX_SOURCE_FILE_BYTES = 64 * 1024 * 1024
MAX_LINKS = 5
OCR_BINARY = discover_ocr()


def feature_enabled(name: str, *, default: bool = False) -> bool:
    value = os.environ.get(name, "").strip().lower()
    if not value:
        return default
    return value in {"1", "true", "yes", "on"}


def require_feature(name: str, capability: str) -> None:
    if not feature_enabled(name):
        raise ValueError(
            f"{capability} is disabled; register the MCP with {name}=1 to opt in"
        )


def iter_string_values(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from iter_string_values(child)
    elif isinstance(value, list):
        for child in value:
            yield from iter_string_values(child)


def extract_local_paths(value: Any) -> list[Path]:
    found: list[Path] = []
    seen: set[str] = set()
    for raw in iter_string_values(value):
        path = Path(raw)
        if not path.is_absolute():
            continue
        key = str(path)
        if key not in seen:
            seen.add(key)
            found.append(path)
    return found


def extract_https_urls(value: Any) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    pattern = re.compile(r"https://[^\s<>\"']+", re.IGNORECASE)
    for raw in iter_string_values(value):
        for match in pattern.findall(raw):
            url = html.unescape(match).rstrip(".,);]，。；）】")
            if url not in seen:
                seen.add(url)
                found.append(url)
                if len(found) >= MAX_LINKS:
                    return found
    return found


def _allowed_media_roots() -> list[Path]:
    roots = [RUNTIME_ROOT]
    home = Path.home()
    roots.extend(
        [
            home / "Library" / "Containers",
            home / "Library" / "Group Containers",
            home / "Library" / "Application Support",
            Path("/private/var/folders"),
            home / "AppData" / "Local",
            home / "AppData" / "Roaming",
        ]
    )
    configured = os.environ.get("WECHAT_MCP_MEDIA_ROOTS", "")
    roots.extend(Path(part) for part in configured.split(os.pathsep) if part)
    return [root.resolve(strict=False) for root in roots]


def validate_local_media_path(path: Path) -> Path:
    resolved = path.resolve(strict=True)
    if not resolved.is_file():
        raise ValueError("media path is not a regular file")
    if resolved.stat().st_size > MAX_SOURCE_FILE_BYTES:
        raise ValueError("media file exceeds 64 MiB safety limit")
    if not any(resolved.is_relative_to(root) for root in _allowed_media_roots()):
        raise ValueError("media path is outside allowed local roots")
    return resolved


def run_ocr(paths: list[Path], languages: list[str] | None = None) -> list[dict[str, Any]]:
    require_feature("WECHAT_MCP_ENABLE_OCR", "image OCR")
    if not OCR_BINARY.exists():
        raise ValueError("OCR helper is not built; run scripts/build-native.sh")
    results: list[dict[str, Any]] = []
    for path in paths[:20]:
        checked = validate_local_media_path(path)
        argv = [str(OCR_BINARY), str(checked)]
        if languages:
            argv.extend(["--languages", ",".join(languages)])
        completed = subprocess.run(
            argv,
            shell=False,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=90,
            check=False,
        )
        if completed.returncode != 0:
            results.append({"path": str(checked), "ok": False, "error": "ocr_failed"})
            continue
        try:
            payload = json.loads(completed.stdout)
        except json.JSONDecodeError:
            payload = {"ok": False, "error": "invalid_ocr_output"}
        if isinstance(payload, dict):
            payload["path"] = str(checked)
            results.append(payload)
    return results


def _xml_text_from_zip(path: Path, prefixes: tuple[str, ...]) -> str:
    chunks: list[str] = []
    with zipfile.ZipFile(path) as archive:
        for name in sorted(archive.namelist()):
            if not name.startswith(prefixes) or not name.endswith(".xml"):
                continue
            info = archive.getinfo(name)
            if info.file_size > MAX_ENRICHMENT_BYTES:
                raise ValueError("document XML member exceeds 4 MiB safety limit")
            data = archive.read(info)
            root = ElementTree.fromstring(data)
            chunks.extend(text.strip() for text in root.itertext() if text.strip())
            if sum(len(chunk) for chunk in chunks) >= MAX_ENRICHMENT_BYTES:
                break
    return "\n".join(chunks)


def _run_text_extractor(argv: list[str]) -> str:
    completed = subprocess.run(
        argv,
        shell=False,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        timeout=90,
        check=False,
    )
    if completed.returncode != 0:
        raise ValueError("document text extraction failed")
    if len(completed.stdout) > MAX_ENRICHMENT_BYTES:
        raise ValueError("document text output exceeds 4 MiB safety limit")
    return completed.stdout.decode("utf-8", errors="replace")


def extract_file_text(path: Path, max_chars: int = 100_000) -> dict[str, Any]:
    require_feature("WECHAT_MCP_ENABLE_FILE_TEXT", "file text extraction")
    checked = validate_local_media_path(path)
    suffix = checked.suffix.lower()
    if suffix in {".txt", ".md", ".json", ".xml", ".csv", ".tsv", ".log", ".yaml", ".yml"}:
        text = checked.read_text(encoding="utf-8", errors="replace")
    elif suffix == ".pdf":
        pdftotext = shutil.which("pdftotext")
        if not pdftotext:
            raise ValueError("pdftotext is required for PDF extraction")
        text = _run_text_extractor([pdftotext, str(checked), "-"])
    elif suffix == ".docx":
        text = _xml_text_from_zip(checked, ("word/",))
    elif suffix == ".pptx":
        text = _xml_text_from_zip(checked, ("ppt/slides/", "ppt/notesSlides/"))
    elif suffix == ".xlsx":
        text = _xml_text_from_zip(checked, ("xl/sharedStrings.xml", "xl/worksheets/"))
    elif suffix in {".rtf", ".rtfd", ".doc", ".odt"}:
        textutil = shutil.which("textutil")
        if not textutil:
            raise ValueError("textutil is required for this document type on macOS")
        text = _run_text_extractor([textutil, "-convert", "txt", "-stdout", str(checked)])
    else:
        return {
            "ok": False,
            "path": str(checked),
            "error": "unsupported_file_type",
            "extension": suffix,
        }
    truncated = len(text) > max_chars
    return {
        "ok": True,
        "path": str(checked),
        "extension": suffix,
        "text": text[:max_chars],
        "truncated": truncated,
        "characters": min(len(text), max_chars),
    }


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


class _HTMLText(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.title = ""
        self._in_title = False
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:  # type: ignore[no-untyped-def]
        if tag.lower() == "title":
            self._in_title = True

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        clean = " ".join(data.split())
        if not clean:
            return
        if self._in_title:
            self.title = (self.title + " " + clean).strip()
        self.parts.append(clean)


def _validate_public_https(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise ValueError("only public HTTPS URLs are allowed")
    if parsed.username or parsed.password:
        raise ValueError("URL credentials are not allowed")
    try:
        addresses = socket.getaddrinfo(parsed.hostname, parsed.port or 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise ValueError("URL hostname could not be resolved") from exc
    for address in addresses:
        ip = ipaddress.ip_address(address[4][0])
        if not ip.is_global:
            raise ValueError("private, local, or special-use URL targets are blocked")


def fetch_link(url: str, max_chars: int = 50_000) -> dict[str, Any]:
    require_feature("WECHAT_MCP_ENABLE_NETWORK", "link fetching")
    opener = build_opener(_NoRedirect())
    current = url
    for _ in range(4):
        _validate_public_https(current)
        request = Request(
            current,
            headers={"User-Agent": "WeChatAgent-MCP/1.0", "Accept": "text/html,text/plain,application/json"},
        )
        try:
            response = opener.open(request, timeout=15)
        except HTTPError as exc:
            if exc.code in {301, 302, 303, 307, 308} and exc.headers.get("Location"):
                current = urljoin(current, exc.headers["Location"])
                continue
            raise ValueError(f"link fetch failed with HTTP {exc.code}") from exc
        content_type = response.headers.get_content_type()
        if content_type not in {"text/html", "text/plain", "application/json"}:
            raise ValueError(f"unsupported link content type: {content_type}")
        raw = response.read(MAX_ENRICHMENT_BYTES + 1)
        if len(raw) > MAX_ENRICHMENT_BYTES:
            raise ValueError("link response exceeds 4 MiB safety limit")
        charset = response.headers.get_content_charset() or "utf-8"
        decoded = raw.decode(charset, errors="replace")
        if content_type == "text/html":
            parser = _HTMLText()
            parser.feed(decoded)
            text = "\n".join(parser.parts)
            title = parser.title
        else:
            text = decoded
            title = ""
        return {
            "ok": True,
            "url": current,
            "content_type": content_type,
            "title": title,
            "text": text[:max_chars],
            "truncated": len(text) > max_chars,
        }
    raise ValueError("too many redirects")


def transcribe_audio(path: Path) -> dict[str, Any]:
    require_feature("WECHAT_MCP_ENABLE_VOICE", "voice transcription")
    checked = validate_local_media_path(path)
    raw_command = os.environ.get("WECHAT_MCP_VOICE_COMMAND_JSON", "")
    if not raw_command:
        return {
            "ok": False,
            "path": str(checked),
            "error": "voice_transcriber_not_configured",
            "next_action": "set WECHAT_MCP_VOICE_COMMAND_JSON to an argv JSON array containing {audio}",
        }
    try:
        command = json.loads(raw_command)
    except json.JSONDecodeError as exc:
        raise ValueError("WECHAT_MCP_VOICE_COMMAND_JSON must be valid JSON") from exc
    if not isinstance(command, list) or not command or not all(isinstance(v, str) for v in command):
        raise ValueError("voice command must be a non-empty JSON string array")
    if "{audio}" not in command:
        raise ValueError("voice command must contain a standalone {audio} argument")
    executable = Path(command[0])
    if not executable.is_absolute() or not executable.exists():
        raise ValueError("voice transcriber executable must be an existing absolute path")
    argv = [str(checked) if value == "{audio}" else value for value in command]
    completed = subprocess.run(
        argv,
        shell=False,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        timeout=300,
        check=False,
    )
    if completed.returncode != 0:
        return {"ok": False, "path": str(checked), "error": "voice_transcription_failed"}
    transcript = completed.stdout.strip()
    if len(transcript.encode("utf-8")) > MAX_ENRICHMENT_BYTES:
        return {"ok": False, "path": str(checked), "error": "voice_output_too_large"}
    return {
        "ok": True,
        "path": str(checked),
        "transcript": transcript[:100_000],
        "truncated": len(transcript) > 100_000,
    }
