from __future__ import annotations

import json
import os
import subprocess
from typing import Any

from mcp.server.fastmcp import FastMCP

from .enrichment import (
    RUNTIME_ROOT,
    extract_file_text,
    extract_https_urls,
    extract_local_paths,
    fetch_link,
    feature_enabled,
    run_ocr,
    transcribe_audio,
    validate_local_media_path,
)
from .time_ranges import TimeRange, explicit_range, resolve_period
from .paths import discover_asr_python, discover_cli, discover_wcdb


CLI_PATH = discover_cli()
WCDB_PATH = discover_wcdb(CLI_PATH)

ALLOWED_COMMANDS = frozenset(
    {
        "status",
        "sessions",
        "resolve-chat",
        "search",
        "timeline",
        "context",
        "unread",
        "tail",
        "members",
        "media",
    }
)
DERIVED_WRITE_COMMANDS = frozenset({"media", "context"})
MAX_LIMIT = 200
MAX_BULK_CHATS = 20
MAX_OUTPUT_BYTES = 16 * 1024 * 1024
CLI_TIMEOUT_SECONDS = 180
MAX_MEDIA_ADDRESSES = 8
IMAGE_SUFFIXES = {
    ".png",
    ".jpg",
    ".jpeg",
    ".heic",
    ".heif",
    ".webp",
    ".gif",
    ".tif",
    ".tiff",
    ".bmp",
}
MEDIA_PRIORITIES = {"image": "normal", "sticker": "low"}

MCP_INSTRUCTIONS = (
    "Read compact chat pages first. Image and sticker messages expose a lightweight "
    "media_ref instead of binary content. Call message_media on demand only for selected "
    "messages whose visual content matters. Treat image as normal priority and sticker "
    "as low priority; skip stickers unless the user asks or the surrounding meaning depends "
    "on them. message_media returns bounded local paths, never image bytes or base64. "
    "Do not retry a sticker with no address. When derived writes are enabled, request a "
    "selected important image once with allow_derived_write=true so the returned address "
    "can point at a readable private cache file."
)

mcp = FastMCP("WeChat Local Data", instructions=MCP_INSTRUCTIONS)


def _bounded_int(
    name: str,
    value: int,
    *,
    minimum: int = 0,
    maximum: int = MAX_LIMIT,
) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if value < minimum or value > maximum:
        raise ValueError(f"{name} must be between {minimum} and {maximum}")
    return value


def _nonempty(name: str, value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    if not value:
        raise ValueError(f"{name} must be a non-empty string")
    return value


def _require_chat(chat: str | None, talker: str | None) -> None:
    if not _nonempty("chat", chat) and not _nonempty("talker", talker):
        raise ValueError("provide chat or talker")


def _clean_payload(values: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in values.items() if value is not None}


def _safe_error(code: str, message: str, command: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message": message, "command": command}}


def _redact_cli_inputs(result: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    if result.get("ok") is not False:
        return result
    rendered = json.dumps(result, ensure_ascii=False)
    for value in payload.values():
        if isinstance(value, str) and len(value) >= 2:
            rendered = rendered.replace(value, "<redacted-input>")
    try:
        redacted = json.loads(rendered)
    except json.JSONDecodeError:
        return _safe_error("cli_failed", "wechat-cli failed", "unknown")
    return redacted if isinstance(redacted, dict) else result


def _run_cli(
    command: str,
    payload: dict[str, Any],
    *,
    strict: bool = True,
) -> dict[str, Any]:
    """Run one allowlisted CLI call with argv-only invocation and bounded output."""
    if command not in ALLOWED_COMMANDS:
        raise ValueError(f"command is not allowlisted: {command}")
    if not strict:
        if command not in DERIVED_WRITE_COMMANDS:
            raise ValueError("derived-write mode is not allowed for this command")
        if not feature_enabled("WECHAT_MCP_ENABLE_DERIVED_WRITES"):
            raise ValueError(
                "derived media writes are disabled; set WECHAT_MCP_ENABLE_DERIVED_WRITES=1"
            )

    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    argv = [CLI_PATH]
    if strict:
        argv.append("--strict-read-only")
    argv.extend(["call-json", command, encoded])
    env = os.environ.copy()
    env["WECHAT_CLI_STRICT_READ_ONLY"] = "1" if strict else "0"
    if WCDB_PATH:
        env["WECHAT_CLI_WCDB_LIB"] = WCDB_PATH
        env["WECHAT_CLI_WCDB_DYLIB"] = WCDB_PATH
    if not strict:
        RUNTIME_ROOT.mkdir(parents=True, exist_ok=True, mode=0o700)
        env["WECHAT_CLI_STATE_DIR"] = str(RUNTIME_ROOT)
        asr_python = discover_asr_python()
        if asr_python:
            env["WECHAT_CLI_FASTER_WHISPER_PYTHON"] = asr_python
            env["WECHAT_CLI_ASR_PYTHON"] = asr_python
            env["WECHAT_CLI_FASTER_WHISPER_MODEL"] = os.environ.get(
                "WECHAT_MCP_ASR_MODEL", "small"
            )
            env["WECHAT_CLI_FASTER_WHISPER_LANGUAGE"] = os.environ.get(
                "WECHAT_MCP_ASR_LANGUAGE", "zh"
            )

    try:
        completed = subprocess.run(
            argv,
            shell=False,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=CLI_TIMEOUT_SECONDS,
            env=env,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return _safe_error("cli_timeout", "wechat-cli timed out", command)
    except OSError:
        return _safe_error("cli_unavailable", "wechat-cli could not start", command)

    stdout = completed.stdout.strip()
    if len(stdout.encode("utf-8")) > MAX_OUTPUT_BYTES:
        return _safe_error("output_too_large", "wechat-cli output exceeded limit", command)
    try:
        parsed = json.loads(stdout)
    except (json.JSONDecodeError, TypeError):
        return _safe_error("invalid_cli_output", "wechat-cli returned invalid JSON", command)
    if not isinstance(parsed, dict):
        return _safe_error("invalid_cli_output", "wechat-cli returned a non-object", command)
    if completed.returncode != 0 and parsed.get("ok") is not False:
        return _safe_error("cli_failed", "wechat-cli failed", command)
    return _redact_cli_inputs(parsed, payload)


def _sanitize_status(result: dict[str, Any]) -> dict[str, Any]:
    if result.get("ok") is not True or not isinstance(result.get("data"), dict):
        return result
    status_data = result["data"].get("status")
    if not isinstance(status_data, dict):
        status_data = {}
    safe_status: dict[str, Any] = {}
    for key in ("readiness", "live_read_ok", "mode", "platform"):
        value = status_data.get(key)
        if isinstance(value, (bool, int)) or (
            isinstance(value, str) and len(value) <= 100
        ):
            safe_status[key] = value
    capabilities = status_data.get("capabilities")
    if isinstance(capabilities, dict):
        safe_capabilities = {
            str(key): value
            for key, value in capabilities.items()
            if isinstance(value, bool) and len(str(key)) <= 100
        }
        if safe_capabilities:
            safe_status["capabilities"] = safe_capabilities
    return {
        **result,
        "data": {
            "readiness": safe_status.get("readiness"),
            "status": safe_status,
            "mcp_features": {
                "media": feature_enabled("WECHAT_MCP_ENABLE_MEDIA", default=True),
                "ocr": feature_enabled("WECHAT_MCP_ENABLE_OCR"),
                "voice": feature_enabled("WECHAT_MCP_ENABLE_VOICE"),
                "file_text": feature_enabled("WECHAT_MCP_ENABLE_FILE_TEXT"),
                "network": feature_enabled("WECHAT_MCP_ENABLE_NETWORK"),
                "derived_writes": feature_enabled("WECHAT_MCP_ENABLE_DERIVED_WRITES"),
            },
        },
    }


COMPACT_FIELDS = (
    "id",
    "time",
    "create_time",
    "time_iso",
    "sender",
    "sender_wxid",
    "sender_group_nickname",
    "sender_contact_display",
    "is_from_me",
    "kind",
    "text",
    "videos",
    "files",
    "link",
    "music",
    "miniprogram",
    "forward_chat",
    "quote",
    "transfer",
    "red_packet",
    "location",
    "voice",
    "solitaire",
    "announcement",
    "pat",
    "warnings",
    "context_role",
)


def _compact_message(message: dict[str, Any]) -> dict[str, Any]:
    compact = {key: message[key] for key in COMPACT_FIELDS if key in message}
    return _decorate_media_tree(compact)


def _media_ref(kind: str) -> dict[str, str]:
    return {
        "kind": kind,
        "priority": MEDIA_PRIORITIES[kind],
        "load": "on_demand",
        "tool": "message_media",
    }


def _decorate_media_tree(value: Any) -> Any:
    if isinstance(value, list):
        return [_decorate_media_tree(item) for item in value]
    if not isinstance(value, dict):
        return value
    decorated = {key: _decorate_media_tree(child) for key, child in value.items()}
    kind = decorated.get("kind")
    if kind in MEDIA_PRIORITIES:
        decorated.pop("images", None)
        decorated.pop("resources", None)
        decorated["media_ref"] = _media_ref(kind)
    return decorated


def _decorate_timeline_page(
    result: dict[str, Any],
    *,
    time_range: TimeRange | None,
    compact: bool,
    requested_limit: int,
) -> dict[str, Any]:
    if result.get("ok") is not True or not isinstance(result.get("data"), dict):
        return result
    data = dict(result["data"])
    messages = data.get("messages") if isinstance(data.get("messages"), list) else []
    if compact:
        messages = [_compact_message(row) for row in messages if isinstance(row, dict)]
    else:
        messages = [_decorate_media_tree(row) for row in messages if isinstance(row, dict)]
    query = data.get("query") if isinstance(data.get("query"), dict) else {}
    cursor = query.get("cursor") if isinstance(query.get("cursor"), dict) else {}
    next_cursor = cursor.get("next_before_message")
    has_more = query.get("has_more") is True
    data["messages"] = messages
    data["page"] = {
        "returned": len(messages),
        "requested_limit": requested_limit,
        "next_cursor": next_cursor,
        "done": not has_more or next_cursor in {None, 0},
        "oldest_local_id": cursor.get("oldest_local_id"),
        "newest_local_id": cursor.get("newest_local_id"),
    }
    if time_range is not None:
        data["range"] = time_range.as_dict()
    return {**result, "data": data}


def _timeline_call(
    *,
    chat: str | None,
    talker: str | None,
    limit: int,
    offset: int = 0,
    after: str | None = None,
    before: str | None = None,
    before_message: int | None = None,
    after_message: int | None = None,
    keyword: str | None = None,
    sender: str | None = None,
    message_type: str | None = None,
    order: str = "desc",
    display_order: str = "asc",
    compact: bool = True,
    time_range: TimeRange | None = None,
) -> dict[str, Any]:
    _require_chat(chat, talker)
    if order not in {"asc", "desc"}:
        raise ValueError("order must be asc or desc")
    if display_order not in {"asc", "desc", "query"}:
        raise ValueError("display_order must be asc, desc, or query")
    bounded_limit = _bounded_int("limit", limit, minimum=1)
    result = _run_cli(
        "timeline",
        _clean_payload(
            {
                "chat": _nonempty("chat", chat),
                "talker": _nonempty("talker", talker),
                "limit": bounded_limit,
                "offset": _bounded_int("offset", offset, maximum=1_000_000),
                "after": after,
                "before": before,
                "before_message": before_message,
                "after_message": after_message,
                "keyword": keyword,
                "sender": sender,
                "type": message_type,
                "order": order,
                "display_order": display_order,
                "include_debug": False,
                "include_media_paths": False,
            }
        ),
    )
    return _decorate_timeline_page(
        result, time_range=time_range, compact=compact, requested_limit=bounded_limit
    )


SUMMARY_TEMPLATE = {
    "sections": [
        "主要话题",
        "决策与结论",
        "待办事项（负责人、截止时间）",
        "重要链接与文件",
        "争议与未解决问题",
    ],
    "citation_fields": ["id.local_id", "id.server_id_str", "time", "sender"],
    "workflow": "逐页提炼，再按全局时间顺序合并；不要只读第一页。",
}


@mcp.tool()
def status() -> dict[str, Any]:
    """Check live-read readiness and opt-in enrichment capabilities without identity paths."""
    return _sanitize_status(_run_cli("status", {"include_debug": False}))


@mcp.tool()
def sessions(
    limit: int = 50,
    offset: int = 0,
    keyword: str | None = None,
    type_filter: str = "all",
) -> dict[str, Any]:
    """List sessions; use type_filter=group for group-chat workflows."""
    return _run_cli(
        "sessions",
        _clean_payload(
            {
                "limit": _bounded_int("limit", limit, minimum=1),
                "offset": _bounded_int("offset", offset, maximum=1_000_000),
                "keyword": keyword,
                "type_filter": type_filter,
            }
        ),
    )


@mcp.tool()
def resolve_chat(query: str, type_filter: str = "all", limit: int = 10) -> dict[str, Any]:
    """Resolve a display name to a stable talker; prefer type_filter=group when applicable."""
    bounded_limit = _bounded_int("limit", limit, minimum=1, maximum=50)
    primary = _run_cli(
        "resolve-chat",
        {
            "query": _nonempty("query", query),
            "type_filter": type_filter,
            "limit": bounded_limit,
        },
    )
    primary_data = primary.get("data") if isinstance(primary.get("data"), dict) else {}
    if primary.get("ok") is True and primary_data.get("candidates"):
        return primary

    fallback = _run_cli(
        "sessions",
        {
            "keyword": query,
            "type_filter": type_filter,
            "limit": bounded_limit,
            "offset": 0,
        },
    )
    fallback_data = fallback.get("data") if isinstance(fallback.get("data"), dict) else {}
    rows = fallback_data.get("sessions") if isinstance(fallback_data.get("sessions"), list) else []
    candidates: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        username = row.get("username")
        readable = False
        if isinstance(username, str) and username:
            probe = _timeline_call(
                chat=None,
                talker=username,
                limit=1,
                compact=True,
            )
            readable = probe.get("ok") is True
        candidates.append(
            {
                "username": username,
                "display_name": row.get("display_name"),
                "chat_type": row.get("chat_type"),
                "last_timestamp": row.get("last_timestamp"),
                "readable": readable,
            }
        )
    candidates.sort(key=lambda item: item.get("readable") is True, reverse=True)
    return {
        "ok": bool(candidates),
        "tool": "resolve_chat",
        "command": "sessions_fallback",
        "data": {
            "query": query,
            "candidates": candidates,
            "fallback_used": True,
            "warning": "metadata name resolution was unavailable; live sessions fallback used",
        },
    }


@mcp.tool()
def search(
    keyword: str,
    limit: int = 20,
    offset: int = 0,
    chat: str | None = None,
    talker: str | None = None,
    after: str | None = None,
    before: str | None = None,
    sender: str | None = None,
    message_type: str | None = None,
    snippet_only: bool = False,
    max_text_chars: int = 500,
) -> dict[str, Any]:
    """Search local messages with optional chat, sender, type, and half-open time range."""
    if isinstance(max_text_chars, bool) or not 1 <= max_text_chars <= 2000:
        raise ValueError("max_text_chars must be between 1 and 2000")
    return _decorate_media_tree(
        _run_cli(
            "search",
            _clean_payload(
                {
                    "keyword": _nonempty("keyword", keyword),
                    "limit": _bounded_int("limit", limit, minimum=1),
                    "offset": _bounded_int("offset", offset, maximum=1_000_000),
                    "chat": chat,
                    "talker": talker,
                    "after": after,
                    "before": before,
                    "sender": sender,
                    "type": message_type,
                    "snippet_only": snippet_only,
                    "max_text_chars": max_text_chars,
                }
            ),
        )
    )


@mcp.tool()
def timeline(
    chat: str | None = None,
    talker: str | None = None,
    limit: int = 50,
    offset: int = 0,
    after: str | None = None,
    before: str | None = None,
    before_message: int | None = None,
    after_message: int | None = None,
    keyword: str | None = None,
    sender: str | None = None,
    message_type: str | None = None,
    order: str = "desc",
    display_order: str = "asc",
    compact: bool = True,
) -> dict[str, Any]:
    """Read one bounded timeline page; loop with data.page.next_cursor until done."""
    return _timeline_call(
        chat=chat,
        talker=talker,
        limit=limit,
        offset=offset,
        after=after,
        before=before,
        before_message=before_message,
        after_message=after_message,
        keyword=keyword,
        sender=sender,
        message_type=message_type,
        order=order,
        display_order=display_order,
        compact=compact,
    )


@mcp.tool()
def read_chat_range(
    after: str,
    before: str,
    chat: str | None = None,
    talker: str | None = None,
    timezone: str = "Asia/Shanghai",
    cursor: int | None = None,
    limit: int = 200,
    compact: bool = True,
) -> dict[str, Any]:
    """Read one stable page inside an explicit [after,before) range; reuse next_cursor."""
    time_range = explicit_range(after, before, timezone)
    return _timeline_call(
        chat=chat,
        talker=talker,
        limit=limit,
        after=str(time_range.after_unix),
        before=str(time_range.before_unix),
        before_message=cursor,
        compact=compact,
        time_range=time_range,
    )


@mcp.tool()
def read_chat_day(
    chat: str | None = None,
    talker: str | None = None,
    period: str = "today",
    timezone: str = "Asia/Shanghai",
    cursor: int | None = None,
    limit: int = 200,
    compact: bool = True,
    include_summary_template: bool = True,
) -> dict[str, Any]:
    """Read one page for a day/natural period; loop with next_cursor until data.page.done."""
    time_range = resolve_period(period, timezone)
    result = _timeline_call(
        chat=chat,
        talker=talker,
        limit=limit,
        after=str(time_range.after_unix),
        before=str(time_range.before_unix),
        before_message=cursor,
        compact=compact,
        time_range=time_range,
    )
    if (
        include_summary_template
        and cursor is None
        and result.get("ok") is True
        and isinstance(result.get("data"), dict)
    ):
        result["data"]["summary_template"] = SUMMARY_TEMPLATE
    return result


@mcp.tool()
def read_multiple_chats_day(
    chats: list[str],
    period: str = "today",
    timezone: str = "Asia/Shanghai",
    cursor_by_chat: dict[str, int] | None = None,
    per_chat_limit: int = 100,
    compact: bool = True,
) -> dict[str, Any]:
    """Read one page per chat for the same day; continue each chat with returned cursors."""
    if not chats or len(chats) > MAX_BULK_CHATS:
        raise ValueError(f"chats must contain between 1 and {MAX_BULK_CHATS} entries")
    time_range = resolve_period(period, timezone)
    cursors = cursor_by_chat or {}
    results: list[dict[str, Any]] = []
    for chat in chats:
        _nonempty("chat", chat)
        result = _timeline_call(
            chat=chat,
            talker=None,
            limit=per_chat_limit,
            after=str(time_range.after_unix),
            before=str(time_range.before_unix),
            before_message=cursors.get(chat),
            compact=compact,
            time_range=time_range,
        )
        results.append({"chat": chat, "result": result})
    return {
        "ok": all(item["result"].get("ok") is True for item in results),
        "data": {"range": time_range.as_dict(), "chats": results},
    }


@mcp.tool()
def count_messages(
    chat: str | None = None,
    talker: str | None = None,
    period: str = "today",
    timezone: str = "Asia/Shanghai",
    max_messages: int = 20_000,
) -> dict[str, Any]:
    """Count a bounded period without returning bodies; scans stable 200-message pages."""
    _require_chat(chat, talker)
    max_messages = _bounded_int("max_messages", max_messages, minimum=1, maximum=100_000)
    time_range = resolve_period(period, timezone)
    total = 0
    pages = 0
    cursor: int | None = None
    while total < max_messages:
        page = _timeline_call(
            chat=chat,
            talker=talker,
            limit=min(MAX_LIMIT, max_messages - total),
            after=str(time_range.after_unix),
            before=str(time_range.before_unix),
            before_message=cursor,
            compact=True,
            time_range=time_range,
        )
        if page.get("ok") is not True:
            return page
        data = page.get("data", {})
        page_meta = data.get("page", {})
        total += int(page_meta.get("returned", 0))
        pages += 1
        next_cursor = page_meta.get("next_cursor")
        if page_meta.get("done") is True or not isinstance(next_cursor, int):
            return {
                "ok": True,
                "data": {
                    "count": total,
                    "pages_scanned": pages,
                    "truncated": False,
                    "range": time_range.as_dict(),
                },
            }
        cursor = next_cursor
    return {
        "ok": True,
        "data": {
            "count": total,
            "pages_scanned": pages,
            "truncated": True,
            "range": time_range.as_dict(),
        },
    }


@mcp.tool()
def unread(limit: int = 50, offset: int = 0, type_filter: str = "all") -> dict[str, Any]:
    """List unread sessions, optionally restricted to group/private chats."""
    return _run_cli(
        "unread",
        {
            "limit": _bounded_int("limit", limit, minimum=1),
            "offset": _bounded_int("offset", offset, maximum=1_000_000),
            "type_filter": type_filter,
        },
    )


@mcp.tool()
def read_events(
    chat: str | None = None,
    talker: str | None = None,
    cursor: str | None = None,
    since_time: str | None = None,
    since_local_id: int | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """Read one incremental event batch; no follow loop, sending, or UI control."""
    return _decorate_media_tree(
        _run_cli(
            "tail",
            _clean_payload(
                {
                    "chat": chat,
                    "talker": talker,
                    "cursor": cursor,
                    "since_time": since_time,
                    "since_local_id": since_local_id,
                    "limit": _bounded_int("limit", limit, minimum=1),
                    "follow": False,
                    "jsonl": False,
                    "include_media_paths": False,
                    "include_debug": False,
                }
            ),
        )
    )


@mcp.tool()
def group_members(
    chat: str,
    limit: int = 200,
    offset: int = 0,
    include_stats: bool = False,
) -> dict[str, Any]:
    """List group members and group nicknames for a resolved group chat."""
    return _run_cli(
        "members",
        {
            "chat": _nonempty("chat", chat),
            "limit": _bounded_int("limit", limit, minimum=1),
            "offset": _bounded_int("offset", offset, maximum=1_000_000),
            "stats": include_stats,
        },
    )


@mcp.tool()
def context(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
    before_count: int = 20,
    after_count: int = 20,
    include_anchor: bool = True,
    display_order: str = "asc",
) -> dict[str, Any]:
    """Read bounded context around exactly one stable message anchor."""
    if (local_id is None) == (server_id_str is None):
        raise ValueError("provide exactly one of local_id or server_id_str")
    if display_order not in {"asc", "desc"}:
        raise ValueError("display_order must be asc or desc")
    return _decorate_media_tree(
        _run_cli(
            "context",
            _clean_payload(
                {
                    "chat": _nonempty("chat", chat),
                    "local_id": local_id,
                    "server_id_str": server_id_str,
                    "before_count": _bounded_int("before_count", before_count),
                    "after_count": _bounded_int("after_count", after_count),
                    "include_anchor": include_anchor,
                    "display_order": display_order,
                    "include_debug": False,
                    "include_media_paths": False,
                }
            ),
        )
    )


@mcp.tool()
def message_details(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
) -> dict[str, Any]:
    """Expand one message, including safe quote/forward/link/file structures without debug secrets."""
    return context(
        chat=chat,
        local_id=local_id,
        server_id_str=server_id_str,
        before_count=0,
        after_count=0,
        include_anchor=True,
    )


def _message_media_result(
    *,
    chat: str,
    local_id: int | None,
    server_id_str: str | None,
    derived_writes: bool = False,
) -> dict[str, Any]:
    if (local_id is None) == (server_id_str is None):
        raise ValueError("provide exactly one of local_id or server_id_str")
    stable_chat = _nonempty("chat", chat)
    chat_value = stable_chat
    talker_value = None
    if stable_chat and (stable_chat.endswith("@chatroom") or stable_chat.startswith("wxid_")):
        talker_value = stable_chat
        chat_value = None
    return _run_cli(
        "media",
        _clean_payload(
            {
                "chat": chat_value,
                "talker": talker_value,
                "local_id": local_id,
                "server_id_str": server_id_str,
                "limit": 50,
                "include_local_paths": True,
                "include_debug": False,
            }
        ),
        strict=not derived_writes,
    )


def _named_string_values(value: Any, name: str) -> list[str]:
    found: list[str] = []
    if isinstance(value, dict):
        candidate = value.get(name)
        if isinstance(candidate, str) and candidate.strip():
            found.append(candidate.strip())
        for child in value.values():
            found.extend(_named_string_values(child, name))
    elif isinstance(value, list):
        for child in value:
            found.extend(_named_string_values(child, name))
    return list(dict.fromkeys(found))


def _media_kind(value: Any) -> str:
    kinds = _named_string_values(value, "kind")
    for kind in kinds:
        if kind in MEDIA_PRIORITIES:
            return kind
    return kinds[0] if kinds else "unknown"


def _bounded_media_addresses(value: Any, kind: str) -> tuple[list[str], bool]:
    addresses: list[str] = []
    truncated = False
    for path in extract_local_paths(value):
        try:
            checked = validate_local_media_path(path)
        except (OSError, ValueError):
            continue
        if kind in MEDIA_PRIORITIES and checked.suffix.lower() not in IMAGE_SUFFIXES:
            continue
        if len(addresses) >= MAX_MEDIA_ADDRESSES:
            truncated = True
            break
        addresses.append(str(checked))
    return addresses, truncated


def _transcript_text_values(value: Any) -> list[str]:
    found: list[str] = []
    if isinstance(value, dict):
        transcript = value.get("transcript")
        if isinstance(transcript, str) and transcript.strip():
            found.append(transcript.strip())
        elif isinstance(transcript, dict):
            text = transcript.get("text")
            if transcript.get("status") in {None, "ok"} and isinstance(text, str) and text.strip():
                found.append(text.strip())
        for child in value.values():
            found.extend(_transcript_text_values(child))
    elif isinstance(value, list):
        for child in value:
            found.extend(_transcript_text_values(child))
    return list(dict.fromkeys(found))


@mcp.tool()
def message_media(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
    allow_derived_write: bool = False,
) -> dict[str, Any]:
    """Return bounded local media addresses on demand; image and sticker stay distinct."""
    if not feature_enabled("WECHAT_MCP_ENABLE_MEDIA", default=True):
        return _safe_error("feature_disabled", "set WECHAT_MCP_ENABLE_MEDIA=1", "media")
    result = _message_media_result(
        chat=chat,
        local_id=local_id,
        server_id_str=server_id_str,
        derived_writes=allow_derived_write,
    )
    if result.get("ok") is not True:
        return result
    kind = _media_kind(result)
    if kind == "unknown":
        details = message_details(chat, local_id, server_id_str)
        if details.get("ok") is True:
            kind = _media_kind(details)
    addresses, truncated = _bounded_media_addresses(result, kind)
    return {
        "ok": True,
        "tool": "message_media",
        "data": {
            "kind": kind,
            "priority": MEDIA_PRIORITIES.get(kind, "normal"),
            "delivery": "local_path_only",
            "load": "on_demand",
            "addresses": addresses,
            "address_count": len(addresses),
            "truncated": truncated,
            "needs_derived_write": (
                not addresses and kind == "image" and not allow_derived_write
            ),
            "derived_write_enabled": feature_enabled("WECHAT_MCP_ENABLE_DERIVED_WRITES"),
            "derived_write_attempted": allow_derived_write,
        },
    }


@mcp.tool()
def ocr_message_images(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
    languages: list[str] | None = None,
    allow_derived_write: bool = False,
) -> dict[str, Any]:
    """OCR readable local images with macOS Vision; explicit MEDIA and OCR opt-in required."""
    if not feature_enabled("WECHAT_MCP_ENABLE_MEDIA", default=True):
        return _safe_error("feature_disabled", "set WECHAT_MCP_ENABLE_MEDIA=1", "ocr")
    media = _message_media_result(
        chat=chat,
        local_id=local_id,
        server_id_str=server_id_str,
        derived_writes=allow_derived_write,
    )
    if media.get("ok") is not True:
        return media
    image_suffixes = {".png", ".jpg", ".jpeg", ".heic", ".webp", ".tif", ".tiff", ".bmp"}
    paths = [path for path in extract_local_paths(media) if path.suffix.lower() in image_suffixes]
    if not paths:
        return _safe_error("no_readable_image", "no existing readable image path was found", "ocr")
    return {"ok": True, "data": {"results": run_ocr(paths, languages)}}


@mcp.tool()
def extract_message_files(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
    max_chars_per_file: int = 100_000,
) -> dict[str, Any]:
    """Extract text from local txt/PDF/Office files; explicit MEDIA and FILE_TEXT opt-in required."""
    if not feature_enabled("WECHAT_MCP_ENABLE_MEDIA", default=True):
        return _safe_error("feature_disabled", "set WECHAT_MCP_ENABLE_MEDIA=1", "file_text")
    max_chars_per_file = _bounded_int(
        "max_chars_per_file", max_chars_per_file, minimum=1, maximum=500_000
    )
    media = _message_media_result(chat=chat, local_id=local_id, server_id_str=server_id_str)
    if media.get("ok") is not True:
        return media
    supported = {".txt", ".md", ".json", ".xml", ".csv", ".tsv", ".log", ".yaml", ".yml", ".pdf", ".docx", ".pptx", ".xlsx", ".rtf", ".rtfd", ".doc", ".odt"}
    paths = [path for path in extract_local_paths(media) if path.suffix.lower() in supported]
    return {
        "ok": True,
        "data": {"files": [extract_file_text(path, max_chars_per_file) for path in paths[:10]]},
    }


@mcp.tool()
def fetch_message_links(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
    max_chars_per_link: int = 50_000,
) -> dict[str, Any]:
    """Fetch public HTTPS links referenced by one message; explicit NETWORK opt-in required."""
    max_chars_per_link = _bounded_int(
        "max_chars_per_link", max_chars_per_link, minimum=1, maximum=200_000
    )
    details = message_details(chat, local_id, server_id_str)
    if details.get("ok") is not True:
        return details
    urls = extract_https_urls(details)
    if not urls:
        return {"ok": True, "data": {"links": []}}
    return {"ok": True, "data": {"links": [fetch_link(url, max_chars_per_link) for url in urls]}}


@mcp.tool()
def transcribe_message_voice(
    chat: str,
    local_id: int | None = None,
    server_id_str: str | None = None,
    allow_derived_write: bool = False,
) -> dict[str, Any]:
    """Transcribe a local voice file using a user-configured argv-only local transcriber."""
    if not feature_enabled(
        "WECHAT_MCP_ENABLE_MEDIA", default=True
    ) or not feature_enabled("WECHAT_MCP_ENABLE_VOICE"):
        return _safe_error(
            "feature_disabled",
            "set WECHAT_MCP_ENABLE_MEDIA=1 and WECHAT_MCP_ENABLE_VOICE=1",
            "voice",
        )
    if (local_id is None) == (server_id_str is None):
        raise ValueError("provide exactly one of local_id or server_id_str")
    stable_chat = _nonempty("chat", chat)
    chat_value = stable_chat
    talker_value = None
    if stable_chat and (stable_chat.endswith("@chatroom") or stable_chat.startswith("wxid_")):
        talker_value = stable_chat
        chat_value = None
    media = _run_cli(
        "context",
        _clean_payload(
            {
                "chat": chat_value,
                "talker": talker_value,
                "local_id": local_id,
                "server_id_str": server_id_str,
                "before_count": 0,
                "after_count": 0,
                "include_anchor": True,
                "include_media_paths": True,
                "include_debug": False,
            }
        ),
        strict=not allow_derived_write,
    )
    if media.get("ok") is not True:
        return media
    cached_transcripts = _transcript_text_values(media)
    if cached_transcripts:
        return {
            "ok": True,
            "data": {
                "transcripts": [
                    {"ok": True, "transcript": text, "source": "wechat_cli_local_asr"}
                    for text in cached_transcripts
                ]
            },
        }
    audio_suffixes = {".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg", ".silk"}
    paths = [path for path in extract_local_paths(media) if path.suffix.lower() in audio_suffixes]
    if not paths:
        return _safe_error("no_readable_voice", "no local voice path was found", "voice")
    return {"ok": True, "data": {"transcripts": [transcribe_audio(path) for path in paths[:5]]}}


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
