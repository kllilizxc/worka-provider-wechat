from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


@dataclass(frozen=True)
class TimeRange:
    after_unix: int
    before_unix: int
    after_iso: str
    before_iso: str
    timezone: str
    label: str

    def as_dict(self) -> dict[str, str | int]:
        return {
            "after": str(self.after_unix),
            "before": str(self.before_unix),
            "after_iso": self.after_iso,
            "before_iso": self.before_iso,
            "timezone": self.timezone,
            "label": self.label,
        }


def _zone(name: str) -> ZoneInfo:
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"unknown timezone: {name}") from exc


def _build(start: datetime, end: datetime, timezone: str, label: str) -> TimeRange:
    if end <= start:
        raise ValueError("time range end must be after start")
    return TimeRange(
        after_unix=int(start.timestamp()),
        before_unix=int(end.timestamp()),
        after_iso=start.isoformat(),
        before_iso=end.isoformat(),
        timezone=timezone,
        label=label,
    )


def resolve_period(
    period: str,
    timezone: str = "Asia/Shanghai",
    *,
    now: datetime | None = None,
) -> TimeRange:
    """Resolve common Chinese/English periods to a half-open local-time range."""
    tz = _zone(timezone)
    current = now.astimezone(tz) if now is not None else datetime.now(tz)
    raw = period.strip()
    normalized = raw.lower().replace(" ", "_")
    today_start = datetime.combine(current.date(), time.min, tzinfo=tz)

    if normalized in {"today", "今天"}:
        return _build(today_start, today_start + timedelta(days=1), timezone, raw)
    if normalized in {"yesterday", "昨天"}:
        return _build(
            today_start - timedelta(days=1), today_start, timezone, raw
        )
    if normalized in {"this_week", "本周", "这周"}:
        start = today_start - timedelta(days=today_start.weekday())
        return _build(start, start + timedelta(days=7), timezone, raw)
    if normalized in {"last_week", "上周"}:
        this_week = today_start - timedelta(days=today_start.weekday())
        return _build(
            this_week - timedelta(days=7), this_week, timezone, raw
        )
    if normalized in {"past_24_hours", "last_24_hours", "过去24小时", "最近24小时"}:
        return _build(current - timedelta(hours=24), current, timezone, raw)

    match = re.fullmatch(r"(?:last|past)_(\d{1,4})_hours?", normalized)
    if match is None:
        match = re.fullmatch(r"(?:最近|过去)(\d{1,4})小时", raw)
    if match is not None:
        hours = int(match.group(1))
        if not 1 <= hours <= 24 * 366:
            raise ValueError("hour range must be between 1 and 8784")
        return _build(current - timedelta(hours=hours), current, timezone, raw)

    try:
        day = datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError(
            "period must be YYYY-MM-DD, today/今天, yesterday/昨天, "
            "this_week/本周, last_week/上周, or last_N_hours/最近N小时"
        ) from exc
    start = datetime.combine(day, time.min, tzinfo=tz)
    return _build(start, start + timedelta(days=1), timezone, raw)


def explicit_range(
    after: str,
    before: str,
    timezone: str = "Asia/Shanghai",
) -> TimeRange:
    """Validate explicit local date/datetime or unix-second range values."""
    tz = _zone(timezone)

    def parse(value: str) -> datetime:
        value = value.strip()
        if re.fullmatch(r"\d{1,12}", value):
            return datetime.fromtimestamp(int(value), tz)
        for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
            try:
                return datetime.strptime(value, fmt).replace(tzinfo=tz)
            except ValueError:
                pass
        raise ValueError(f"unsupported time value: {value}")

    return _build(parse(after), parse(before), timezone, "explicit")
