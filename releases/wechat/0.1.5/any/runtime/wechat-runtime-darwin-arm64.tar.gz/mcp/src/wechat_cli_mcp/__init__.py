"""Strict read-only MCP bridge for wechat-cli."""
