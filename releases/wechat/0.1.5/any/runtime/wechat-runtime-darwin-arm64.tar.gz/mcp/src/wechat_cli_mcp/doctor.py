from __future__ import annotations

import json
import os
import platform
import shutil
from pathlib import Path

from .paths import discover_cli, discover_ocr, discover_wcdb


def diagnostic() -> dict[str, object]:
    cli = discover_cli()
    wcdb = discover_wcdb(cli)
    ocr = discover_ocr()
    return {
        "platform": platform.system().lower(),
        "architecture": platform.machine().lower(),
        "python": platform.python_version(),
        "cli_found": Path(cli).is_file() or shutil.which(cli) is not None,
        "wcdb_found": bool(wcdb and Path(wcdb).is_file()),
        "ocr_found": ocr.is_file(),
        "config_found": (Path.home() / ".config" / "wxcli" / "config.json").is_file(),
        "next_action": "run the MCP status tool" if wcdb else "run the platform installer",
    }


def main() -> None:
    print(json.dumps(diagnostic(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
